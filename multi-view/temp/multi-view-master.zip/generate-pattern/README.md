# Generate calibration pattern

## Example
- Checkerboard, A1, 70mm(board size), 8(board width), 11(board height)

`./gen-pattern.py -c 8 -r 11 -T checkerboard -a A1 -u mm -s 70`
